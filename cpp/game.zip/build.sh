g++ main.cpp -lSDL2 -lSDL2_ttf -lSDL2_image -o game
